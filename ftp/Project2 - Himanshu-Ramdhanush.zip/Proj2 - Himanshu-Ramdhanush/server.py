#!/usr/bin/env python3
import argparse, os, random, socket, struct

DATA_CONST = 0x5555
ACK_CONST  = 0xAAAA

def udp_checksum16(data: bytes) -> int:
    
    if len(data) % 2 == 1:
        data += b"\x00"
    s = 0
    for i in range(0, len(data), 2):
        w = (data[i] << 8) + data[i+1]
        s = (s + w) & 0xFFFF
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF

def make_ack(seq: int) -> bytes:
    return struct.pack("!IHH", seq, 0x0000, ACK_CONST)

def parse_data(pkt: bytes):
    if len(pkt) < 8:
        return None
    seq, cksum, magic = struct.unpack("!IHH", pkt[:8])
    if magic != DATA_CONST:
        return None
    payload = pkt[8:]
    return seq, cksum, payload

def main():
    ap = argparse.ArgumentParser(description="Simple-FTP server (receiver)")
    ap.add_argument("port", type=int, help="listening UDP port (7735)")
    ap.add_argument("outfile", type=str, help="output file path")
    ap.add_argument("p", type=float, help="packet loss probability (0<p<1)")
    args = ap.parse_args()

    # op file
    os.makedirs(os.path.dirname(args.outfile) or ".", exist_ok=True)
    f = open(args.outfile, "wb")

    expected = 0
    addr_of_client = None

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("", args.port))

    try:
        while True:
            pkt, addr = sock.recvfrom(65535)
            # Probabilistic drop
            if random.random() <= args.p:
                parsed = parse_data(pkt)
                if parsed is not None:
                    seq, _, _ = parsed
                    print(f"Packet loss, sequence number = {seq}")
                continue

            parsed = parse_data(pkt)
            if parsed is None:
                continue

            seq, cksum, payload = parsed
            if udp_checksum16(payload) != cksum:
                continue

            if seq == expected:
                f.write(payload)
                f.flush()
                sock.sendto(make_ack(seq), addr)
                expected += 1
                addr_of_client = addr
            else:
                # Out-of-sequence: do nothing
                pass
    finally:
        f.close()

if __name__ == "__main__":
    main()



# python3 server.py 7735 recv-file.txt 0.05