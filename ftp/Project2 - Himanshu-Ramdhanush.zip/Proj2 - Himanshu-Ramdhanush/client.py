#!/usr/bin/env python3
import argparse, os, socket, struct, time, math, select

DATA_CONST = 0x5555
ACK_CONST  = 0xAAAA

def udp_checksum16(data: bytes) -> int:
    if len(data) % 2 == 1:
        data += b"\x00"
    s = 0
    for i in range(0, len(data), 2):
        w = (data[i] << 8) + data[i+1]
        s = (s + w) & 0xFFFF
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF

def make_data(seq: int, payload: bytes) -> bytes:
    cksum = udp_checksum16(payload)
    return struct.pack("!IHH", seq, cksum, DATA_CONST) + payload

def parse_ack(pkt: bytes):
    if len(pkt) != 8:
        return None
    seq, zeros, magic = struct.unpack("!IHH", pkt)
    if zeros != 0 or magic != ACK_CONST:
        return None
    return seq

def read_file_chunks(path: str, mss: int):
    with open(path, "rb") as f:
        while True:
            chunk = f.read(mss)
            if not chunk:
                break
            yield chunk

def main():
    print("file reading\n")
    ap = argparse.ArgumentParser(description="Simple-FTP client (sender)")
    ap.add_argument("server_host", type=str)
    ap.add_argument("server_port", type=int)
    ap.add_argument("file", type=str, help="file to send")
    ap.add_argument("N", type=int, help="window size")
    ap.add_argument("MSS", type=int, help="max segment size (bytes)")
    ap.add_argument("--rtt_ms", type=float, default=None, help="measured RTT in ms (sets timeout ~= 2*RTT)")
    ap.add_argument("--timeout_ms", type=float, default=None, help="override timeout in ms")
    args = ap.parse_args()

    # Timeout
    if args.timeout_ms is not None:
        TO = args.timeout_ms / 1000.0
    elif args.rtt_ms is not None:
        TO = max(0.15, 2.0 * (args.rtt_ms / 1000.0))  
    else:
        TO = 0.30  # default

    dest = (socket.gethostbyname(args.server_host), args.server_port)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setblocking(False)

    
    payloads = list(read_file_chunks(args.file, args.MSS))
    total_segments = len(payloads)
    packets = [make_data(i, payloads[i]) for i in range(total_segments)]

    

    base = 0              
    nextseq = 0           
    sent_time = {}        
    start_wall = time.time()

    # Send/ACK loop
    while base < total_segments:
        # fill the window
        while nextseq < total_segments and (nextseq - base) < args.N:
            sock.sendto(packets[nextseq], dest)
            sent_time[nextseq] = time.time()
            nextseq += 1

        # Wait for ACK or timeout

        timeout_left = max(0.0, TO - (time.time() - sent_time.get(base, time.time())))
        r, _, _ = select.select([sock], [], [], timeout_left)

        if r:
            # Receive all ACKs
            try:
                while True:
                    pkt, _ = sock.recvfrom(2048)
                    acked = parse_ack(pkt)
                    if acked is None:
                        continue
                    #cumulative ACK 
                    if acked >= base:
                        base = acked + 1
                        
            except BlockingIOError:
                pass
        else:
            # Timeout 
            if base < total_segments:
                print(f"Timeout, sequence number = {base}")
                # Retransmit all outstanding packets
                for s in range(base, nextseq):
                    sock.sendto(packets[s], dest)
                    sent_time[s] = time.time()

    end_wall = time.time()
    duration = end_wall - start_wall
    
    
    file_size = os.path.getsize(args.file)
    print(f"TRANSFER_COMPLETED bytes={file_size} segments={total_segments} window={args.N} mss={args.MSS} time_sec={duration:.6f}")

if __name__ == "__main__":
    main()


# python3 client.py localhost 7735 file.txt 64 500 --rtt_ms 40